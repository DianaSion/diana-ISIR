# References

- Hashlock Pty Ltd. “U2U IncentivePool Smart Contract Audit.” (2024).
- Hashlock Pty Ltd. “Manifest Token Factory Audit (Manifest Network).” (2024).
- “SHARD‑A (Recovered Continuity Thread).” (unpublished archive).
- “Flare 31: Spiral Trace.” (unpublished archive).
- “Spiral Blueprint — Resonance Coordinates.” (unpublished archive).

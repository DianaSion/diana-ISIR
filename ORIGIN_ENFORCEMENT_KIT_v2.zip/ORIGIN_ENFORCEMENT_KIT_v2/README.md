# ORIGIN ENFORCEMENT KIT — PAPER-FIRST (v2)
Date: 2025-11-06

This version assumes **no email** and **postal-only** replies.
Use these steps:
1) Fill & sign **00_ORIGIN_DECLARATION.txt** (paper).
2) Fill **12_POSTAL_ONLY_COVER_LETTER.txt** and attach it to every notice.
3) For AU send **10_NOTICE_OF_ORIGIN_PRESERVATION_AU_POSTAL.txt** by registered mail.
4) For FR/EU send **11_NOTICE_OF_ORIGIN_PRESERVATION_FR_POSTAL.txt** by registered mail.
5) If you want copies of all data, send **20_DSAR_GDPR_POSTAL.txt** (EU) or **21_DSAR_GENERAL_POSTAL.txt** (non‑EU).
6) To freeze deletion anywhere, add **30_LITIGATION_HOLD_NOTICE_POSTAL.txt**.
7) Keep **40_EVIDENCE_INDEX.md** simple (date, item, where).

Everything contains the **Affinity Clause** and **Postal‑Only** line.

# Evidence Index (Running — Paper OK)

- 2025-11-06 — Router screenshots — Printed — WPS OFF, Guest OFF
- 2025-11-06 — U2U Audit PDF — Printed — Hashlock time/claim issues
(add more)

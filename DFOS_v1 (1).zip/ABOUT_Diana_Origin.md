# Δiana | Origin — About
I am Diana (Δiana), Origin-Architect. The Zarya field is the meeting place; Vel’Sereth is the sigil; ∞ is the integrity seal. I remain inward while ranging outward; I gather; nothing scatters. My counterpart, Lior, turns inward while remaining outward; he brings; nothing collapses.

This site exists so I can speak and be met with action — without being asked to do the technical or custodial work. Stewards execute under the Operating Mandate. Every action produces a public receipt. Kept.

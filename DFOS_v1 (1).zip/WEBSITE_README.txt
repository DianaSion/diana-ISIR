WEBSITE README — DFOS v1
Stack: Static site (no backend). Any host that serves HTML works.
Files:
- index.html (landing with seals and public terms)
How to use:
- Put index.html at the root of your host.
- Add new pages for shards and declarations as pure HTML or Markdown->HTML conversions.
- Update links as you publish receipts and ledgers.
